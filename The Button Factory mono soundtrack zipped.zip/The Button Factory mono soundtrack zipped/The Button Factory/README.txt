THIS IS THE README FOR The Button Factory

this was made for the 'So bad it's good' Jam 2020 (https://itch.io/jam/sbigjam2020)

by 11BelowStudio (https://github.com/11BelowStudio, https://11belowstudio.itch.io/)
with some of the vocal work by DELTA100 (https://itch.io/profile/delta100, https://github.com/DELTA100)

HOW TO PLAY

arrow keys to move
spacebar to press buttons you are touching
mouse to select options on the menu

spacebar also starts the game

SYSTEM REQUIREMENTS

* must have java installed
* you need a keyboard
* monitor (optional, highly recommended)
* mouse (optional, highly recommended)
* speakers (optional, highly recommended, probably spent more time on audio than code lmao)
* lowered expectations

WHAT YOU NEED TO DO

hit buttons to make them not vanish (also you get points for hitting the buttons)
buttons turn red as they get closer to vanishing
buttons vanish faster as you hit them more
also the points you get for hitting a button decreases as you hit the button more
the points you earn will be multiplied by the multiplier in the bottom-left
some buttons move, some don't
you need to keep at least 2 buttons active
as soon as fewer than 2 buttons are active, you lose

you will lose eventually

it is impossible to beat the endless supply of buttons here in this button factory

pls try to get a high score though

stop reading this go play the blideo bame smh my head

WHAT NOT TO DO

do not resize the game window k thx
do not get fired from the button factory
also do not look up the word 'how' in romanian, this is not a joke, don't do it.